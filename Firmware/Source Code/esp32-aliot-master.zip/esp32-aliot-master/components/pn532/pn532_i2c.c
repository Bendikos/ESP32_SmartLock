#include "pn532_i2c.h"
#include <string.h>
#include <stdint.h>

static const char *TAG = "PN532";

// 命令宏定义，提升可读性
// #define CMD_WAKEUP {0x00, 0x00, 0xff, 0x02, 0xfe, 0xd4, 0x55, 0xd7, 0x00}
// #define CMD_SAMCONF {0x00, 0x00, 0xff, 0x04, 0xfc, 0xd4, 0x14, 0x01, 0x00, 0x17, 0x00}
// #define CMD_READ1 {0x00, 0x00, 0xff, 0x04, 0xfc, 0xd4, 0x4a, 0x02, 0x00, 0xe0, 0x00}

// 传输和接收函数，减少重复代码
esp_err_t pn532_transmit(const uint8_t *cmd, size_t len)
{
    return i2c_master_transmit(pn532_handle, cmd, len, -1);
}

esp_err_t pn532_receive(uint8_t *data, size_t len)
{
    return i2c_master_receive(pn532_handle, data, len, -1);
}

void pn532_send_command(const uint8_t *cmd, size_t cmd_len, uint8_t *response, size_t response_len)
{
    pn532_transmit(cmd, cmd_len);
    vTaskDelay(pdMS_TO_TICKS(200));
    pn532_receive(response, response_len);
    ESP_LOG_BUFFER_HEX(TAG, response, response_len);
}

void dev_pn532_initialization(void)
{

}

void PN532_GPIO_Init(void)
{

}

void PN532_Reset(void)
{

}
