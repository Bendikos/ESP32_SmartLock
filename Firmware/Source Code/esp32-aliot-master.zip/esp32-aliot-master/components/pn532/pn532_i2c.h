#ifndef __PN532_I2C_H__
#define __PN532_I2C_H__

#include "driver/i2c_master.h"
#include "esp_attr.h"
#include "esp_log.h"
#include "esp_attr.h"
#include "driver/gpio.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <driver/i2c_master.h>

// External I2C Handles
extern i2c_master_bus_handle_t bus_handle;
extern i2c_master_dev_handle_t pn532_handle;

esp_err_t pn532_transmit(const uint8_t *cmd, size_t len);
esp_err_t pn532_receive(uint8_t *data, size_t len);
void pn532_send_command(const uint8_t *cmd, size_t cmd_len, uint8_t *response, size_t response_len);
void dev_pn532_initialization(void);
void PN532_GPIO_Init(void);
void PN532_Reset(void);

#endif // __PN532_I2C_H__
