
#ifndef ZW101_H_
#define ZW101_H_

#include <stdio.h>
#include "driver/uart.h"
#include "driver/gpio.h"
#include "esp_log.h"

#define EX_UART_NUM UART_NUM_2

unsigned char zw101_GetEcho();
unsigned char zw101_PS_HandShake();
unsigned short zw101_checksum(unsigned char *pakcet, size_t len);
unsigned char zw101_sendpack(unsigned char *packet, size_t len);
unsigned char zw101_recivepack();
unsigned char zw101_ControlBLN(unsigned char featuer_code, unsigned char start_color, unsigned char end_color, unsigned char cycle_time);
unsigned char zw101_waitForHandshake(unsigned int timeout);
unsigned int zw101_PS_AutoEnroll(unsigned short ID, unsigned char entry_num, unsigned short parameter);
unsigned char zw101_PS_AutoIdentify(unsigned char rating_fraction, unsigned short ID);
unsigned char zw101_PS_ReadIndexTable();
unsigned char zw101_PS_DeletChar(unsigned short ID, unsigned short num);
unsigned char zw101_PS_Cancel();
unsigned char zw101_PS_Sleep();
#endif
