#include "zw101.h"

static const char *TAG = "zw101";

// 计算校验和
unsigned short zw101_checksum(unsigned char *packet, size_t len)
{
    unsigned short checksum = 0;
    for (size_t i = 6; i < len - 2; i++)
    { // 从第6个字节开始累加
        checksum += packet[i];
    }
    return checksum;
}

// 发送数据包
unsigned char zw101_sendpack(unsigned char *packet, size_t len)
{
    size_t sentBytes = 0;
    for (size_t i = 0; i < len; i++)
    {
        if (uart_write_bytes(EX_UART_NUM, (const char *)&packet[i], 1) == 1)
        {
            sentBytes++;
        }
        else
        {
            ESP_LOGE("UART", "Failed to send byte %zu", i);
            return 0; // 发送失败
        }
    }
    uart_flush(EX_UART_NUM);
    ESP_LOG_BUFFER_HEX(TAG, packet, len);
    return (sentBytes == len) ? 1 : 0; // 返回1表示发送成功，0表示部分失败
}

// 指纹模块握手
unsigned char zw101_PS_HandShake()
{
    // 初始化串口
    // mySerial.begin(57600, SERIAL_8N1, 16, 17); // 确保串口初始化

    unsigned char packet[] = {
        0xEF, 0x01,             // 包头
        0xFF, 0xFF, 0xFF, 0xFF, // 设备默认地址
        0x01,                   // 包标识,代表命令包
        0x00, 0x03,             // 包长度
        0x35,                   // 指令码
        0x00, 0x39              // 校验和（待计算）
    };

    unsigned short checksum = zw101_checksum(packet, sizeof(packet));
    packet[sizeof(packet) - 2] = (checksum >> 8) & 0xFF; // 高字节
    packet[sizeof(packet) - 1] = checksum & 0xFF;        // 低字节

    // 发送数据包
    zw101_sendpack(packet, sizeof(packet));

    return 0; // 返回响应结果
}

// 控制背光
unsigned char zw101_ControlBLN(unsigned char featuer_code, unsigned char start_color, unsigned char end_color, unsigned char cycle_time)
{
    unsigned char packet[] = {
        0xEF, 0x01,             // 包头
        0xFF, 0xFF, 0xFF, 0xFF, // 设备默认地址
        0x01,                   // 包标识,代表命令包
        0x00, 0x07,             // 包长度
        0x3C,                   // 指令码
        featuer_code,           // 功能码
        start_color, end_color, // 开始与结束颜色
        cycle_time,             // 设置循环次数为无限循环
        0x00, 0x00              // 校验和（待计算）
    };

    unsigned short checksum = zw101_checksum(packet, sizeof(packet));
    packet[sizeof(packet) - 2] = (checksum >> 8) & 0xFF; // 高字节
    packet[sizeof(packet) - 1] = checksum & 0xFF;        // 低字节

    // 发送数据包
    zw101_sendpack(packet, sizeof(packet));

    return 0;
}

// 自动注册
unsigned int zw101_PS_AutoEnroll(unsigned short ID, unsigned char entry_num, unsigned short parameter)
{
    unsigned char packet[] = {
        0xEF, 0x01,                                // 包头
        0xFF, 0xFF, 0xFF, 0xFF,                    // 设备默认地址
        0x01,                                      // 包标识, 代表命令包
        0x00, 0x08,                                // 包长度 (确保长度正确)
        0x31,                                      // 指令码
        (ID >> 8) & 0xFF, ID & 0xFF,               // ID，高字节和低字节
        entry_num,                                 // 数据项数量或编号（entry_num）
        (parameter >> 8) & 0xFF, parameter & 0xFF, // 参数的高字节和低字节
        0x00, 0x00                                 // 校验和（待计算）
    };

    unsigned short checksum = zw101_checksum(packet, sizeof(packet));
    packet[sizeof(packet) - 2] = (checksum >> 8) & 0xFF; // 高字节
    packet[sizeof(packet) - 1] = checksum & 0xFF;        // 低字节

    // 发送数据包
    zw101_sendpack(packet, sizeof(packet));

    return 0;
}

// 自动识别
unsigned char zw101_PS_AutoIdentify(unsigned char rating_fraction, unsigned short ID)
{
    unsigned char packet[] = {
        0xEF, 0x01,                  // 包头
        0xFF, 0xFF, 0xFF, 0xFF,      // 设备默认地址
        0x01,                        // 包标识, 代表命令包
        0x00, 0x08,                  // 包长度
        0x32,                        // 指令码
        rating_fraction,             // 分级等级
        (ID >> 8) & 0xFF, ID & 0xFF, // ID，高字节和低字节
        0x00, 0x05,                  // 参数 (parameter)
        0x00, 0x00                   // 校验和
    };

    unsigned short checksum = zw101_checksum(packet, sizeof(packet));
    packet[sizeof(packet) - 2] = (checksum >> 8) & 0xFF; // 高字节
    packet[sizeof(packet) - 1] = checksum & 0xFF;        // 低字节

    // 发送数据包
    zw101_sendpack(packet, sizeof(packet));

    return 0;
}
// 读索引表
unsigned char zw101_PS_ReadIndexTable()
{
    unsigned char packet[] = {
        0xEF, 0x01,             // 包头
        0xFF, 0xFF, 0xFF, 0xFF, // 设备默认地址
        0x01,                   // 包标识, 代表命令包
        0x00, 0x04,             // 包长度
        0x1F,                   // 指令码
        00,                     // 页码
        0x00, 0x00              // 校验和
    };

    unsigned short checksum = zw101_checksum(packet, sizeof(packet));
    packet[sizeof(packet) - 2] = (checksum >> 8) & 0xFF; // 高字节
    packet[sizeof(packet) - 1] = checksum & 0xFF;        // 低字节

    // 发送数据包
    zw101_sendpack(packet, sizeof(packet));

    return 0;
}
unsigned char zw101_PS_DeletChar(unsigned short ID, unsigned short num)
{
    unsigned char packet[] = {
        0xEF, 0x01,                    // 包头
        0xFF, 0xFF, 0xFF, 0xFF,        // 设备默认地址
        0x01,                          // 包标识, 代表命令包
        0x00, 0x07,                    // 包长度
        0x0C,                          // 指令码
        (ID >> 8) & 0xFF, ID & 0xFF,   // ID，高字节和低字节
        (num >> 8) & 0xFF, num & 0xFF, // 删除个数，高字节和低字节
        0x00, 0x00                     // 校验和
    };

    unsigned short checksum = zw101_checksum(packet, sizeof(packet));
    packet[sizeof(packet) - 2] = (checksum >> 8) & 0xFF; // 高字节
    packet[sizeof(packet) - 1] = checksum & 0xFF;        // 低字节

    // 发送数据包
    zw101_sendpack(packet, sizeof(packet));

    return 0;
}

unsigned char zw101_PS_Cancel()
{
    unsigned char packet[] = {
        0xEF, 0x01,             // 包头
        0xFF, 0xFF, 0xFF, 0xFF, // 设备默认地址
        0x01,                   // 包标识, 代表命令包
        0x00, 0x03,             // 包长度
        0x30,                   // 指令码
        0x00, 0x00              // 校验和
    };

    unsigned short checksum = zw101_checksum(packet, sizeof(packet));
    packet[sizeof(packet) - 2] = (checksum >> 8) & 0xFF; // 高字节
    packet[sizeof(packet) - 1] = checksum & 0xFF;        // 低字节

    // 发送数据包
    zw101_sendpack(packet, sizeof(packet));

    return 0;
}
unsigned char zw101_PS_Sleep()
{
    unsigned char packet[] = {
        0xEF, 0x01,             // 包头
        0xFF, 0xFF, 0xFF, 0xFF, // 设备默认地址
        0x01,                   // 包标识, 代表命令包
        0x00, 0x03,             // 包长度
        0x33,                   // 指令码
        0x00, 0x00              // 校验和
    };

    unsigned short checksum = zw101_checksum(packet, sizeof(packet));
    packet[sizeof(packet) - 2] = (checksum >> 8) & 0xFF; // 高字节
    packet[sizeof(packet) - 1] = checksum & 0xFF;        // 低字节

    // 发送数据包
    zw101_sendpack(packet, sizeof(packet));

    return 0;
}
