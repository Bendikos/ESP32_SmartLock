#ifndef _HTTPS_OTA_H_
#define _HTTPS_OTA_H_

#include "esp_err.h"

// ota完成回调函数
typedef void (*ota_finish_callback_t)(int code);

/** 设置https
 * @param url 下载升级包地址
 * @param f 升级完成回调函数
 * @return ESP_OK or ESP_FAIL
 */
esp_err_t https_ota_config(const char *url, ota_finish_callback_t f);

/** 启动HTTPS OTA升级
 * @param 无
 * @return ESP_OK or ESP_FAIL
 */
esp_err_t https_ota_start(void);

#endif
