#ifndef __FT6336U_DRIVER_H_
#define __FT6336U_DRIVER_H_

#include <stdint.h>
#include "driver/i2c_master.h"
#include "driver/gpio.h"
#include "esp_log.h"

extern i2c_master_bus_handle_t bus_handle;
extern i2c_master_dev_handle_t touch_handle;

// 芯片寄存器
#define TD_STATUS 0x02
#define P1_XH 0x03
#define P1_XL 0x04
#define P1_YH 0x05
#define P1_YL 0x06
#define P2_XH 0x09
#define P2_XL 0x0A
#define P2_YH 0x0B
#define P2_YL 0x0C

#define ID_G_CIPHER_HIGH 0xA3
#define ID_G_CIPHER_MIDE 0x9F
#define ID_G_CIPHER_LOW 0xA0
#define ID_G_LIB_VERSION_H 0xA1
#define ID_G_LIB_VERSION_L 0xA2
#define ID_G_FIRMID 0xA6
#define ID_G_FOCALTECH_ID 0xA8
#define ID_G_PMODE 0xA5

typedef struct
{
    uint32_t CPIPHER;
    uint16_t LIB_VERSION;
    uint8_t FIRMWARE_VERSION;
    uint8_t VENDOR_ID;
} FT6336U_IC_INFO;

typedef struct
{
    uint8_t touch_num;
    uint16_t touch0_x;
    uint16_t touch0_y;
    uint16_t touch1_x;
    uint16_t touch1_y;
} FT6336U_TOUCH_POS;

void ft6336u_init();
void ft6336u_reset();
void ft6336u_read_ic_info(FT6336U_IC_INFO *info);
void ft6336u_read_touch_pos(FT6336U_TOUCH_POS *touch_pos);
uint8_t ft6336u_read_power_mode();

#endif // __FT6336U_DRIVER_H_
