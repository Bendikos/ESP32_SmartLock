#ifndef _ALIOT_H_
#define _ALIOT_H_
#include <stdint.h>

// 阿里云MQTTURL
#define ALIOT_MQTT_URL "iot-06z009vbywh7j17.mqtt.iothub.aliyuncs.com"

// 产品KEY
#define ALIOT_PRODUCT_KEY "k20qpRLnCFG"

// 设备名称
#define ALIOT_DEVICE_NAME "ESP32RGB01"

// 产品SECRET
#define ALIOT_PRODUCT_SECRET "jxsOHNWDdlVBPDQb"

// YourRegionId 北京:cn-beijing;上海:cn-shanghai;深圳:cn-shenzhen
#define ALIOT_REGION_ID "cn-shanghai"

// 设备密钥
#define ALIOT_DEVICE_SECRET "d4180180c0aa943759e46c5c139cb1a1"

#define SOFTWARE_VERSION get_app_version()

/**
 * 获取设备名称
 * @param 无
 * @return 设备名称
 */
char *aliot_get_devicename(void);

/**
 * 获取客户端id
 * @param 无
 * @return 客户端id
 */
char *aliot_get_clientid(void);

/**
 * 获取应用程序版本号
 * @param 无
 * @return 版本号
 */
const char *get_app_version(void);

/**
 * OTA升级成功后调用此函数，防止程序回滚
 * @param 无
 * @return 无
 */
void aliot_ota_cancel_rollback(void);

// 根证书
extern const char *g_aliot_ca;

// mqtt端口
extern const unsigned short g_mqtt_port;

#endif
