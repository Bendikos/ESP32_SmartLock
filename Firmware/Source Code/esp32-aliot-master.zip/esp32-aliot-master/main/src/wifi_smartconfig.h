#ifndef _WIFI_SMARTCONFIG_H_
#define _WIFI_SMARTCONFIG_H_
#include "esp_err.h"


esp_err_t smartconfig_start(void);

void initialise_wifi(void);


#endif
