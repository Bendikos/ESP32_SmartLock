#ifndef __MAIN_H_
#define __MAIN_H_

#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "freertos/event_groups.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "aliot_mqtt.h"
#include "esp_console.h"
#include "linenoise/linenoise.h"
#include "argtable3/argtable3.h"
#include "driver/uart.h"
#include "esp_vfs_dev.h"
#include "esp_system.h"
#include "cJSON.h"
#include "aliot.h"
#include "aliot_dm.h"
#include "driver/gpio.h"
#include "esp_flash_partitions.h"
#include "esp_ota_ops.h"
#include "wifi_smartconfig.h"
#include "esp_wifi.h"
#include "FT6336U_Driver.h"
#include "ssd1306.h"
#include "pn532_i2c.h"
#include "zw101.h"
// #define old
#define I2C_MASTER_SCL_IO 33      /*!< GPIO for I2C master clock */
#define I2C_MASTER_SDA_IO 32      /*!< GPIO for I2C master data */
#define I2C_MASTER_NUM I2C_NUM_0  /*!< I2C port number */
#define I2C_MASTER_FREQ_HZ 100000 /*!< I2C master clock frequency */

#define BUZZER_CTL_PIN 19
#define LOCK_CTL_PIN 22

#define ZW101_TX_PIN 17
#define ZW101_RX_PIN 16
#define PATTERN_CHR_NUM (1) /*!< Set the number of consecutive and identical characters received by receiver which defines a UART pattern*/
#define ZW101_INT_PIN 18
#define ZW101_CTL_PIN 5
#define BUF_SIZE (1024)
#define RD_BUF_SIZE (BUF_SIZE)

#define PN532_INT_PIN 27
#define PN532_RST_PIN 26

#define PN532_I2C_ADDRESS ((uint8_t)0x24)

#define FT6336U_RST_PIN 21      // 复位低电平有效
#define FT6336U_INT_PIN 25      // 中断低电平有效
#define FT6336U_Slave_Addr 0x38 // I2C从机地址

#define OLED_ADDRESS ((uint8_t)0x3C)

#endif