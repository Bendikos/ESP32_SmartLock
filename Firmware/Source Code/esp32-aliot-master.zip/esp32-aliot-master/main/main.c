#include "main.h"

#define TAG "main"

#define EV_WIFI_CONNECTED_BIT (1 << 0)
#define EV_WIFI_DISCONNECTED_BIT (1 << 1)

time_t g_now;
extern uint8_t s_chDisplayBuffer[128][8];

static EventGroupHandle_t s_wifi_ev;

uint8_t CMD_READ1[] = {0x00, 0x00, 0xff, 0x04, 0xfc, 0xd4, 0x4a, 0x02, 0x00, 0xe0, 0x00};

static QueueHandle_t uart2_queue;
/**
 *0X00 空闲状态
 *0X01 读索引表状态
 *0X02 注册指纹状态
 *0X03 删除指纹状态
 *0X04 验证指纹状态
 *0X0A 取消指令状态
 */
uint8_t STATE = 0x00;

// 指纹的数量
uint8_t FINGERPRINT_NUMBER = 0;

// zw101是否处在通电模式下
uint8_t ZW101_STATE = 0;

// 数组下标是flash中指纹的ID号
uint8_t FINGERPRINT_DATA[64];

// led灯的状态
static int led_level = 0;

i2c_master_bus_handle_t bus_handle;
i2c_master_dev_handle_t oled_handle;
i2c_master_dev_handle_t pn532_handle;
i2c_master_dev_handle_t touch_handle;

SemaphoreHandle_t touch_semaphore;
SemaphoreHandle_t pn532_semaphore;
SemaphoreHandle_t zw101_semaphore;
QueueHandle_t xQueue_buzzer;

uint8_t carduid[4];
bool pn532_getuid;

uint8_t matrix_keyboard[4][3] = {
    {'1', '2', '3'},
    {'4', '5', '6'},
    {'7', '8', '9'},
    {'*', '0', '#'}};

static void IRAM_ATTR gpio_isr_handler(void *arg)
{
    uint32_t gpio_num = (uint32_t)arg;
    // ESP_EARLY_LOGI(TAG, "GPIO[%d] interrupt triggered", gpio_num);
    if (gpio_num == PN532_INT_PIN && gpio_get_level(PN532_INT_PIN) == 0)
    {
        xSemaphoreGiveFromISR(pn532_semaphore, NULL);
    }
    else if (gpio_num == FT6336U_INT_PIN && gpio_get_level(FT6336U_INT_PIN) == 0)
    {
        xSemaphoreGiveFromISR(touch_semaphore, NULL);
    }
    else if (gpio_num == ZW101_INT_PIN && gpio_get_level(ZW101_INT_PIN) == 1)
    {
        xSemaphoreGiveFromISR(zw101_semaphore, NULL);
    }
}
// 蜂鸣器任务
void buzzer_task(void *pvParameters)
{
    uint8_t receivedMessage = 0;
    while (1)
    {
        if (xQueueReceive(xQueue_buzzer, &receivedMessage, pdMS_TO_TICKS(1000)) == pdPASS)
        {
            ESP_LOGI(TAG, "receivedMessage: %d", receivedMessage);

            if (receivedMessage == 1) // 开门成功
            {
                gpio_set_level(LOCK_CTL_PIN, 1); // 给 电磁锁 通电
                gpio_set_level(BUZZER_CTL_PIN, 0);
                vTaskDelay(pdMS_TO_TICKS(800));
                gpio_set_level(BUZZER_CTL_PIN, 1);
                gpio_set_level(ZW101_CTL_PIN, 1); // 给 ZW101 断电
                ZW101_STATE = 0;
                gpio_set_level(LOCK_CTL_PIN, 0); // 给 电磁锁 断电
            }
            else if (receivedMessage == 0) // 开门失败
            {
                gpio_set_level(BUZZER_CTL_PIN, 0);
                vTaskDelay(pdMS_TO_TICKS(150));
                gpio_set_level(BUZZER_CTL_PIN, 1);
                vTaskDelay(pdMS_TO_TICKS(50));
                gpio_set_level(BUZZER_CTL_PIN, 0);
                vTaskDelay(pdMS_TO_TICKS(150));
                gpio_set_level(BUZZER_CTL_PIN, 1);
                gpio_set_level(ZW101_CTL_PIN, 1); // 给 ZW101 断电
                ZW101_STATE = 0;
            }
        }
    }
}
void pn532_task(void *arg)
{
    uint8_t res[19] = {0};
    uint8_t ack[7] = {0};

    gpio_config_t *pn532_int_gpio_config = malloc(sizeof(gpio_config_t));

    // 设置结构体的字段
    pn532_int_gpio_config->pin_bit_mask = (1ULL << PN532_INT_PIN);
    pn532_int_gpio_config->mode = GPIO_MODE_INPUT;
    pn532_int_gpio_config->pull_up_en = GPIO_PULLUP_ENABLE;
    pn532_int_gpio_config->pull_down_en = GPIO_PULLDOWN_DISABLE;
    pn532_int_gpio_config->intr_type = GPIO_INTR_NEGEDGE;

    gpio_config(pn532_int_gpio_config);

    // 使用完成后释放内存
    free(pn532_int_gpio_config);

    while (1)
    {
        if (xSemaphoreTake(pn532_semaphore, portMAX_DELAY) == pdTRUE)
        {
            if (i2c_master_receive(pn532_handle, res, sizeof(res), 100) == ESP_OK && res[0] == 0x01)
            {
                // ESP_LOG_BUFFER_HEX(TAG, res, sizeof(res));
                uint8_t id_len = res[13];
                memcpy(carduid, &res[14], id_len);
                // ssd1306_draw_string(oled_handle, 30, 30, );
                ESP_LOG_BUFFER_HEX("UID:", carduid, id_len);

                pn532_getuid = true;

                i2c_master_transmit(pn532_handle, CMD_READ1, sizeof(CMD_READ1), 500);
                vTaskDelay(pdMS_TO_TICKS(200));
                i2c_master_receive(pn532_handle, ack, sizeof(ack), 500);
                res[0] = 0x00;
                // ESP_LOG_BUFFER_HEX(TAG, ack, sizeof(ack));
            }

            xSemaphoreTake(pn532_semaphore, portMAX_DELAY);
            // ESP_LOGI(TAG, "Waiting...");
        }
    }
}
void zw101_task(void *param)
{
    gpio_set_level(ZW101_CTL_PIN, 0); // 给 ZW101 供电
    vTaskDelay(pdMS_TO_TICKS(500));
    gpio_set_level(ZW101_CTL_PIN, 1); // 给 ZW101 断电
    while (1)
    {
        // 等待信号量被释放
        if (xSemaphoreTake(zw101_semaphore, portMAX_DELAY) == pdTRUE)
        {
            // STATE = 0X04;
            // gpio_set_level(ZW101_CTL_PIN, 1); // 给 ZW101 供电
            // vTaskDelay(pdMS_TO_TICKS(1000));
            // STATE = 0X00;
            // gpio_set_level(ZW101_CTL_PIN, 0); // 给 ZW101 断电
            if (ZW101_STATE == 0)
            {
                ZW101_STATE = 1;
                gpio_set_level(ZW101_CTL_PIN, 0); // 给 ZW101 供电
                STATE = 4;
            }
            else if (ZW101_STATE == 1)
            {
                if (STATE == 4)
                {
                    zw101_PS_AutoIdentify(0x02, 0xFFFF); // 自动识别指纹
                }
            }
        }
    }
}
// 触摸屏任务：中断模式响应触摸数据
void touch_task(void *pvParameters)
{
    uint8_t row, col;
    FT6336U_TOUCH_POS touch;

    while (1)
    {
        // 等待信号量被释放
        if (xSemaphoreTake(touch_semaphore, portMAX_DELAY) == pdTRUE)
        {
            ft6336u_read_touch_pos(&touch);
            row = touch.touch0_y / 80;
            col = touch.touch0_x / 80;
            if (touch.touch_num == 0)
            {
                ESP_LOGI("触摸按键: ", "%c", matrix_keyboard[row][col]);
            }
        }
        vTaskDelay(pdMS_TO_TICKS(50));
    }
}

void uart_event_task(void *pvParameters)
{
    uart_event_t event;
    uint8_t *dtmp = (uint8_t *)malloc(RD_BUF_SIZE);
    uint8_t open = 1;
    uint8_t nopen = 0;
    for (;;)
    {
        // Waiting for UART event.
        if (xQueueReceive(uart2_queue, (void *)&event, (TickType_t)portMAX_DELAY))
        {
            bzero(dtmp, RD_BUF_SIZE);
            size_t buffered_size;
            uint8_t i = 0, j = 0, num = 0;
            switch (event.type)
            {
            case UART_DATA:
                if (STATE == 0X01 && event.size >= 11)
                {
                    ESP_LOGI(TAG, "读索引表-收到的字节数: %d", event.size);
                    uart_read_bytes(EX_UART_NUM, dtmp, event.size, portMAX_DELAY);
                    ESP_LOG_BUFFER_HEX(TAG, dtmp, event.size); // 打印接收到的数据
                    uint8_t data_th = 0;

                    for (i = 10; i < 18; i++)
                    {
                        data_th = dtmp[i];
                        for (j = 0; j < 8; j++)
                        {
                            FINGERPRINT_DATA[num] = (data_th >> j) & 0x01;
                            num++;
                        }
                    }
                    FINGERPRINT_NUMBER = 0;
                    for (i = 0; i < 64; i++)
                    {
                        if (FINGERPRINT_DATA[i] == 1)
                        {
                            ESP_LOGI(TAG, "存在指纹-id: %d", i);
                            FINGERPRINT_NUMBER++;
                        }
                    }
                    ESP_LOGI(TAG, "指纹数量: %d", FINGERPRINT_NUMBER);
                }
                if (STATE == 0X02 && event.size >= 11)
                {
                    // ESP_LOGI(TAG, "注册指纹-收到的字节数: %d", event.size);
                    uart_read_bytes(EX_UART_NUM, dtmp, event.size, portMAX_DELAY);
                    // ESP_LOG_BUFFER_HEX(TAG, dtmp, event.size); // 打印接收到的数据
                    if (dtmp[10] == 0x00 && dtmp[11] == 0x00)
                    {
                        if (dtmp[9] == 0x00)
                            ESP_LOGI(TAG, "注册指令合法");
                    }
                    else if (dtmp[11] <= 0x0A)
                    {
                        if (dtmp[9] == 0x00 && dtmp[10] == 0x03)
                            ESP_LOGI(TAG, "第%d次指纹捕捉成功", dtmp[11]);
                        if (dtmp[9] == 0x26)
                            ESP_LOGI(TAG, "注册指纹超时");
                    }
                    if (dtmp[11] == 0xF0)
                    {
                        if (dtmp[9] == 0x00)
                            ESP_LOGI(TAG, "合并模板成功");
                    }
                    if (dtmp[11] == 0xF1)
                    {
                        if (dtmp[9] == 0x00)
                            ESP_LOGI(TAG, "已注册检测通过");
                    }
                    if (dtmp[11] == 0xF2)
                    {
                        if (dtmp[9] == 0x00)
                            ESP_LOGI(TAG, "模板存储成功");
                    }
                }
                if (STATE == 0X03 && event.size >= 11)
                {
                    ESP_LOGI(TAG, "删除指纹-收到的字节数: %d", event.size);
                    uart_read_bytes(EX_UART_NUM, dtmp, event.size, portMAX_DELAY);
                    ESP_LOG_BUFFER_HEX(TAG, dtmp, event.size); // 打印接收到的数据
                    if (dtmp[9] == 0x00)
                    {
                        ESP_LOGI(TAG, "删除指纹-成功");
                        if (FINGERPRINT_NUMBER >= 1)
                            FINGERPRINT_NUMBER--;
                    }
                    if (dtmp[9] == 0x01)
                    {
                        ESP_LOGI(TAG, "删除指纹-收包有错");
                    }
                    if (dtmp[9] == 0x10)
                    {
                        ESP_LOGI(TAG, "删除指纹-失败");
                    }
                }
                if (STATE == 0X04 && event.size >= 11)
                {
                    ESP_LOGI(TAG, "验证指纹-收到的字节数: %d", event.size);
                    uart_read_bytes(EX_UART_NUM, dtmp, event.size, portMAX_DELAY);
                    ESP_LOG_BUFFER_HEX(TAG, dtmp, event.size); // 打印接收到的数据

                    if (dtmp[10] == 0x01)
                    {
                        if (dtmp[9] == 0x00)
                            ESP_LOGI(TAG, "验证指纹-获取图像成功");
                        else if (dtmp[9] == 0x26)
                        {
                            ESP_LOGI(TAG, "验证指纹-获取图像超时");
                            gpio_set_level(ZW101_CTL_PIN, 1); // 给 ZW101 断电
                            ZW101_STATE = 0;
                        }
                    }
                    if (dtmp[10] == 0x05)
                    {
                        if (dtmp[9] == 0x00)
                        {
                            xQueueSend(xQueue_buzzer, &open, pdMS_TO_TICKS(10));
                            ESP_LOGI(TAG, "验证指纹-搜到了指纹");
                        }
                        else if (dtmp[9] == 0x09)
                        {
                            xQueueSend(xQueue_buzzer, &nopen, pdMS_TO_TICKS(10));
                            ESP_LOGI(TAG, "验证指纹-没搜索到指纹");
                        }
                        else if (dtmp[9] == 0x24)
                        {
                            xQueueSend(xQueue_buzzer, &nopen, pdMS_TO_TICKS(10));
                            ESP_LOGI(TAG, "验证指纹-指纹库为空");
                        }
                    }
                }
                if (STATE == 0X0A && event.size >= 11)
                {
                    ESP_LOGI(TAG, "取消指令-收到的字节数: %d", event.size);
                    uart_read_bytes(EX_UART_NUM, dtmp, event.size, portMAX_DELAY);
                    ESP_LOG_BUFFER_HEX(TAG, dtmp, event.size); // 打印接收到的数据
                    if (dtmp[9] == 0x00)
                    {
                        ESP_LOGI(TAG, "取消指令-成功");
                    }
                    else if (dtmp[9] == 0x01)
                    {
                        ESP_LOGI(TAG, "取消指令-失败");
                    }
                    else if (dtmp[9] == 0x31)
                    {
                        ESP_LOGI(TAG, "取消指令-功能与加密等级不匹配");
                    }
                }
                break;

            case UART_PATTERN_DET:
                uart_get_buffered_data_len(EX_UART_NUM, &buffered_size);
                int pos = uart_pattern_pop_pos(EX_UART_NUM);
                ESP_LOGI(TAG, "[UART PATTERN DETECTED] pos: %d, buffered size: %d", pos, buffered_size);
                if (pos == -1)
                {
                    // There used to be a UART_PATTERN_DET event, but the pattern position queue is full so that it can not
                    // record the position. We should set a larger queue size.
                    // As an example, we directly flush the rx buffer here.
                    uart_flush_input(EX_UART_NUM);
                }
                else
                {
                    uart_read_bytes(EX_UART_NUM, dtmp, pos, 100 / portTICK_PERIOD_MS);
                    uint8_t pat[PATTERN_CHR_NUM + 1];
                    memset(pat, 0, sizeof(pat));
                    uart_read_bytes(EX_UART_NUM, pat, PATTERN_CHR_NUM, 100 / portTICK_PERIOD_MS);
                    if (pat[0] == 0X55)
                    {
                        ESP_LOGI(TAG, "pat[0] == 0X55 ZW101就绪");
                        if (STATE == 0X00)
                        {
                            STATE = 0X01;              // 读索引表
                            zw101_PS_ReadIndexTable(); // 读索引表命令
                        }
                        if (STATE == 0X04)
                        {
                            zw101_PS_AutoIdentify(0x02, 0xFFFF); // 自动识别指纹
                        }
                    }
                }
                break;

            default:
                break;
            }
        }
    }
    free(dtmp);
    dtmp = NULL;
    vTaskDelete(NULL);
}

void device_initialization()
{
    /* Configure parameters of an UART driver,
     * communication pins and install the driver */
    uart_config_t uart_config = {
        .baud_rate = 57600,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };

    // Install UART driver, and get the queue.
    uart_driver_install(EX_UART_NUM, BUF_SIZE * 2, BUF_SIZE * 2, 20, &uart2_queue, 0);
    uart_param_config(EX_UART_NUM, &uart_config);

    // Set UART log level
    // esp_log_level_set(TAG, ESP_LOG_INFO);
    // Set UART pins (using UART0 default pins ie no changes.)
    uart_set_pin(EX_UART_NUM, ZW101_RX_PIN, ZW101_TX_PIN, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);

    // Set uart pattern detect function.
    uart_enable_pattern_det_baud_intr(EX_UART_NUM, 0x55, PATTERN_CHR_NUM, 9, 100, 100);

    // Reset the pattern queue length to record at most 20 pattern positions.
    uart_pattern_queue_reset(EX_UART_NUM, 20);

    // Create a task to handler UART event from ISR
    xTaskCreate(uart_event_task, "uart_event_task", 8192, NULL, 10, NULL);

    i2c_master_bus_config_t i2c_mst_config = {
        .clk_source = I2C_CLK_SRC_DEFAULT,
        .i2c_port = I2C_MASTER_NUM,
        .scl_io_num = I2C_MASTER_SCL_IO,
        .sda_io_num = I2C_MASTER_SDA_IO,
        .glitch_ignore_cnt = 7,
        .flags.enable_internal_pullup = true,
    };
    ESP_ERROR_CHECK(i2c_new_master_bus(&i2c_mst_config, &bus_handle));

    i2c_device_config_t dev_cfg = {
        .dev_addr_length = I2C_ADDR_BIT_LEN_7,
        .device_address = PN532_I2C_ADDRESS,
        .scl_speed_hz = I2C_MASTER_FREQ_HZ,
    };
    ESP_ERROR_CHECK(i2c_master_bus_add_device(bus_handle, &dev_cfg, &pn532_handle));
    ESP_LOGI(TAG, "pn532 device created");

    dev_cfg.dev_addr_length = I2C_ADDR_BIT_LEN_7;
    dev_cfg.device_address = FT6336U_Slave_Addr;
    dev_cfg.scl_speed_hz = I2C_MASTER_FREQ_HZ;

    ESP_ERROR_CHECK(i2c_master_bus_add_device(bus_handle, &dev_cfg, &touch_handle));
    ESP_LOGI(TAG, "ft6336u device created");

    dev_cfg.dev_addr_length = I2C_ADDR_BIT_LEN_7;
    dev_cfg.device_address = OLED_ADDRESS;
    dev_cfg.scl_speed_hz = I2C_MASTER_FREQ_HZ;

    ESP_ERROR_CHECK(i2c_master_bus_add_device(bus_handle, &dev_cfg, &oled_handle));
    ESP_LOGI(TAG, "oled12864 device created");
}

void gpio_initialization()
{
    gpio_config_t pn532_reset_gpio_config = {
        .pin_bit_mask = (1ULL << PN532_RST_PIN),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE};
    gpio_config(&pn532_reset_gpio_config);

    gpio_config_t ft6336u_int_gpio_config = {
        .pin_bit_mask = (1ULL << FT6336U_INT_PIN),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_NEGEDGE};
    gpio_config(&ft6336u_int_gpio_config);

    gpio_config_t ft6336u_reset_gpio_config = {
        .pin_bit_mask = (1ULL << FT6336U_RST_PIN),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE};
    gpio_config(&ft6336u_reset_gpio_config);

    gpio_config_t zw101_int_gpio_config = {
        .pin_bit_mask = (1ULL << ZW101_INT_PIN),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_ENABLE,
        .intr_type = GPIO_INTR_POSEDGE};
    gpio_config(&zw101_int_gpio_config);

    gpio_config_t zw101_ctl_gpio_config = {
        .pin_bit_mask = (1ULL << ZW101_CTL_PIN),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_ENABLE,
        .intr_type = GPIO_INTR_DISABLE};
    gpio_config(&zw101_ctl_gpio_config);

    gpio_config_t buzzer_gpio_config = {
        .pin_bit_mask = (1ULL << BUZZER_CTL_PIN),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE};
    gpio_config(&buzzer_gpio_config);
    gpio_set_level(BUZZER_CTL_PIN, 1); // 给 蜂鸣器 断电

    gpio_config_t lock_gpio_config = {
        .pin_bit_mask = (1ULL << LOCK_CTL_PIN),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_ENABLE,
        .intr_type = GPIO_INTR_DISABLE};
    gpio_config(&lock_gpio_config);
    gpio_set_level(LOCK_CTL_PIN, 0); // 给 电磁锁 断电

    // reset device (ft6336u, pn532)
    gpio_set_level(FT6336U_RST_PIN, 0);
    gpio_set_level(PN532_RST_PIN, 0);
    vTaskDelay(pdMS_TO_TICKS(400));
    gpio_set_level(PN532_RST_PIN, 1);
    gpio_set_level(FT6336U_RST_PIN, 1);
    vTaskDelay(pdMS_TO_TICKS(10));

    // ft6336u read
    FT6336U_IC_INFO info;
    ft6336u_read_ic_info(&info);
    ESP_LOGI("IC_INFO", "CIPHER: 0x%lx, LIB_VERSION: 0x%x, FIRMWARE_VERSION: 0x%x, VENDOR_ID: 0x%x",
             info.CPIPHER, info.LIB_VERSION, info.FIRMWARE_VERSION, info.VENDOR_ID);
    xTaskCreate(touch_task, "touch_task", 8192, NULL, 10, NULL);

    // oled12864 display
    ssd1306_init(oled_handle);
    ssd1306_clear_screen(oled_handle, 0x00);
    ssd1306_draw_bitmap(oled_handle, 0, 2, &c_chSingal816[0], 16, 8);
    ssd1306_draw_bitmap(oled_handle, 24, 2, &c_chBluetooth88[0], 8, 8);
    ssd1306_draw_bitmap(oled_handle, 40, 2, &c_chMsg816[0], 16, 8);
    ssd1306_draw_bitmap(oled_handle, 64, 2, &c_chGPRS88[0], 8, 8);
    ssd1306_draw_bitmap(oled_handle, 90, 2, &c_chAlarm88[0], 8, 8);
    ssd1306_draw_bitmap(oled_handle, 112, 2, &c_chBat816[0], 16, 8);
    ssd1306_refresh_gram(oled_handle);

    gpio_install_isr_service(0);
    gpio_isr_handler_add(PN532_INT_PIN, gpio_isr_handler, (void *)PN532_INT_PIN);
    gpio_isr_handler_add(FT6336U_INT_PIN, gpio_isr_handler, (void *)FT6336U_INT_PIN);
    gpio_isr_handler_add(ZW101_INT_PIN, gpio_isr_handler, (void *)ZW101_INT_PIN);

    vTaskDelay(1000 / portTICK_PERIOD_MS); // run the test for 10 seconds
    // pn532 read card
    uint8_t ack[7];
    uint8_t CMD_WAKEUP[] = {0x00, 0x00, 0xff, 0x02, 0xfe, 0xd4, 0x55, 0xd7, 0x00};
    uint8_t CMD_SAMCONF[] = {0x00, 0x00, 0xff, 0x04, 0xfc, 0xd4, 0x14, 0x01, 0x00, 0x17, 0x00};
    pn532_send_command(CMD_WAKEUP, sizeof(CMD_WAKEUP), ack, sizeof(ack));
    pn532_send_command(CMD_WAKEUP, sizeof(CMD_WAKEUP), ack, sizeof(ack));
    pn532_send_command(CMD_SAMCONF, sizeof(CMD_SAMCONF), ack, sizeof(ack));
    pn532_send_command(CMD_READ1, sizeof(CMD_READ1), ack, sizeof(ack));
    xTaskCreate(pn532_task, "pn532_task", 16384, NULL, 10, NULL);
}

/**
 * 板级初始化，自己在这个函数加初始化代码
 * @param 无
 * @return 无
 */
void board_init(void)
{
    esp_err_t ret_val = ESP_OK;
    ret_val = nvs_flash_init();
    if (ret_val == ESP_ERR_NVS_NO_FREE_PAGES || ret_val == ESP_ERR_NVS_NEW_VERSION_FOUND)
    {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret_val = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret_val);
}
/**
 * 当后台下发了属性值时，会调用此回调函数
 * @param name 属性值的名字
 * @param value 属性值
 * @return 无
 */
void aliot_property_cb(const char *name, cJSON *value_js)
{
    if (strcmp(name, "LightSwitch") == 0)
    {
        int value = cJSON_GetNumberValue(value_js);
        led_level = value;
        ESP_LOGI(TAG, "aliot set property->name:%s,value:%i", name, value);
    }
}
esp_err_t ssd1306_show_time(i2c_master_dev_handle_t oled_handle)
{
    struct tm timeinfo;
    char strftime_buf[64];
    time(&g_now);
    g_now++;
    setenv("TZ", "GMT-8", 1);
    tzset();
    localtime_r(&g_now, &timeinfo);
    strftime(strftime_buf, sizeof(strftime_buf), "%c", &timeinfo);

    ssd1306_draw_3216char(oled_handle, 0, 16, strftime_buf[11]);
    ssd1306_draw_3216char(oled_handle, 16, 16, strftime_buf[12]);
    ssd1306_draw_3216char(oled_handle, 32, 16, strftime_buf[13]);
    ssd1306_draw_3216char(oled_handle, 48, 16, strftime_buf[14]);
    ssd1306_draw_3216char(oled_handle, 64, 16, strftime_buf[15]);
    ssd1306_draw_1616char(oled_handle, 80, 32, strftime_buf[16]);
    ssd1306_draw_1616char(oled_handle, 96, 32, strftime_buf[17]);
    ssd1306_draw_1616char(oled_handle, 112, 32, strftime_buf[18]);

    char *day = strftime_buf;
    day[3] = '\0';
    ssd1306_draw_string(oled_handle, 87, 16, (const uint8_t *)day, 14, 1);
    ssd1306_draw_string(oled_handle, 0, 52, (const uint8_t *)"MUSIC", 12, 0);
    ssd1306_draw_string(oled_handle, 52, 52, (const uint8_t *)"MENU", 12, 0);
    ssd1306_draw_string(oled_handle, 98, 52, (const uint8_t *)"PHONE", 12, 0);

    return ssd1306_refresh_gram(oled_handle);
}
void app_main(void)
{

    vTaskDelay(pdMS_TO_TICKS(1500));
    board_init();                             // 板级初始化
    aliot_set_property_cb(aliot_property_cb); // 设置属性下发控制回调函数

    /*********************pn532初始化********************************** */
    pn532_semaphore = xSemaphoreCreateBinary();
    touch_semaphore = xSemaphoreCreateBinary();
    zw101_semaphore = xSemaphoreCreateBinary();
    // 创建队列，可存储 1 个 uchar 类型的元素
    xQueue_buzzer = xQueueCreate(1, sizeof(uint8_t));
    if (xQueue_buzzer == NULL)
    {
        printf("Failed to create queue\n");
        return;
    }
    xTaskCreate(zw101_task, "zw101_task", 8192, NULL, 10, NULL);
    xTaskCreate(buzzer_task, "buzzer_task", 8192, NULL, 10, NULL);

    device_initialization();
    gpio_initialization();

    ESP_LOGI(TAG, "this is aliot version %s,just for test!", get_app_version());
#if 0
    // initialise_wifi();
#endif

    while (1)
    {

        vTaskDelay(6000 / portTICK_PERIOD_MS); // run the test for 10 seconds
        // gpio_set_level(ZW101_CTL_PIN, 0);      // 给ZW101 供电
        // vTaskDelay(6000 / portTICK_PERIOD_MS); // run the test for 10 seconds
        // gpio_set_level(ZW101_CTL_PIN, 1);

        // zw101_PS_AutoIdentify(0x02, 0xFFFF); // 自动识别指纹
        // zw101_PS_ReadIndexTable();              // 读索引表
    }
}
